package com.akh.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akh.entity.DepartmentEntity;
import com.akh.service.DepartmentService;

@RestController
@RequestMapping("/department")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;
	
	@PostMapping
	public DepartmentEntity create(@RequestBody DepartmentEntity departmentEntity) {
		return departmentService.create(departmentEntity);
	}
	
	@GetMapping("/alldepartments")
	public List<DepartmentEntity> getAll(){
		return departmentService.getAll();
	}
	
	@GetMapping("/byid/{deptId}")
	public DepartmentEntity getOne(@PathVariable Integer deptId) {
		return departmentService.getOne(deptId);
	}
}
