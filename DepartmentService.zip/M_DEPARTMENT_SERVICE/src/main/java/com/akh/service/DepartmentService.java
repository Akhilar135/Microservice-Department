package com.akh.service;

import java.util.List;

import com.akh.entity.DepartmentEntity;

public interface DepartmentService {
	
	public DepartmentEntity create(DepartmentEntity departmentEntity);
	public DepartmentEntity getOne(Integer deptId);
	public List<DepartmentEntity> getAll();

}
