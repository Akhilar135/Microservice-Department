package com.akh.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akh.entity.DepartmentEntity;
import com.akh.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;
	@Override
	public DepartmentEntity create(DepartmentEntity departmentEntity) {
		// TODO Auto-generated method stub
		return departmentRepository.save(departmentEntity);
	}

	@Override
	public DepartmentEntity getOne(Integer deptId) {
		// TODO Auto-generated method stub
		return departmentRepository.findById(deptId).orElseThrow(()->new RuntimeException("Not found"));
	}

	@Override
	public List<DepartmentEntity> getAll() {
		// TODO Auto-generated method stub
		return departmentRepository.findAll();
	}

	
}
